// stdafx.cpp : source file that includes just the standard includes
// CameraControl.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"




CString g_imgPreFix="3dIMG_"; //ͼ��ǰ׺
int g_imgIdx=0;
CString g_savePath=" ";  //��ʯ��Ӧ���ļ���